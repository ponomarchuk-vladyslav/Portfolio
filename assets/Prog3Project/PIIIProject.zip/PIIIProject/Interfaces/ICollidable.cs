﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PIIIProject
{
    /// <summary>
    /// Interface with no implementation. Allows to easily check if an object can be collided with.
    /// </summary>
    public interface ICollidable
    {
    }
}
