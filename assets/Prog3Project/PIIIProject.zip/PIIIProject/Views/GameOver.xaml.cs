﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace PIIIProject.Views
{
    /// <summary>
    /// Interaction logic for GameOver.xaml
    /// </summary>
    public partial class GameOver : Window
    {
        /// <summary>
        /// Public constructor for the gameover screen. Displays either a victory or a defeat.
        /// </summary>
        /// <param name="win">Boolean representing if you win or not. If true, it will congratulate you on winning. If false, displays defeat.</param>
        public GameOver(bool win)
        {
            InitializeComponent();

            if (!win)
            {
                WinText.Visibility = Visibility.Hidden;
                LoseText.Visibility = Visibility.Visible;
            }
        }

        /// <summary>
        /// Handler for the end game button click. Closes the screen.
        /// </summary>
        private void BtnEnd_Clicked(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
